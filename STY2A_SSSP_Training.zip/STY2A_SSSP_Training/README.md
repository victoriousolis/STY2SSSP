# Fortis STY2A SSSP Safety Professional Training (English / Español)

In-depth, self-paced training for **safety professionals coming onto Project Comstock STY 2A**, built the same way as the STY 10 course and following the **Fortis Construction, Inc. Site-Specific Safety Plan, Project Comstock STY 2A, Rev. 2.0 (05.2025)** page by page: the front matter, every numbered section from 1.0 to 39.0, and Appendices A–D.

## How it works
0. **Choose a language:** every visit opens on a language-choice screen, English or Español. The whole course (lessons, checks, exam, photo captions and certificate) runs in the language picked. Progress is saved separately for each language on that device, and the top bar has a **Language / Idioma** button to switch back. Spanish certificates carry "-ES-" in the certificate ID.
1. **Sign in:** first/last name, employee/EL #, position, company, project, direct supervisor.
2. **22 modules, 172 short lessons, in SSSP order.** Long sections are broken into one lesson per role or subsection (for example, the Safety Engineer/Representative and the Safety Administrator are separate lessons), so trainees read one portion at a time. Modules unlock one at a time. Every lesson shows an olive **"SSSP · section · page"** badge so the trainee can open the same page of the plan, and every module card shows the section and page range it covers.
3. **A check after every lesson:** each lesson ends with 3–6 questions, more for longer lessons, each testing a different point from that lesson (745 in total). Next stays locked until every answer is correct, and passing the last lesson's check completes the module.
4. **Hands-on activity:** Module 13, Lesson 3 (§15.0 High-Risk Mitigation) is a drag-and-drop exercise; Lesson 2 first teaches the condition-to-document table it uses. Trainees drag each required document (Crane Lift Plan, Silica WECP, EEW Permit, MOP, Hot Work Permit, Confined Space Permit, Fall Protection & Rescue Plan, Don't Hit It form) onto its condition. On a phone they tap the document, then tap the condition. Next stays locked until all 8 are correct and the lesson check is passed.
5. **Final exam:** **50 questions** drawn evenly from every module out of the **745-question bank**, with shuffled answer order. **80%** to pass, unlimited retakes, and a review of missed questions that names the module to revisit.
6. **Certificate:** a Fortis-branded landscape certificate issued by **Donavan Griffen, Campus Site Lead, Fortis Construction, Inc.** (no signature line). It has Google-color corner stripes with white construction-icon cut-outs, "Project Comstock · STY 2A" above "Certificate of Completion", the trainee's details centered around a teal **Fortis Safety Education** seal, and a faded mountain scene along the bottom. The certificate shown on screen at the end of the course and the downloaded PDF are drawn by the same code, so they are identical. It can also be printed, or emailed if you set an address.

Progress saves in the trainee's browser, so they can stop and resume on the same device. Plan on **2–4 hours**. Progress is saved separately from the STY 10 course.

## Review mode (currently OFF)
`REVIEW_MODE: true` in `CONFIG` opens everything for reviewers: all modules and the final exam are unlocked, Next is never locked, the lesson bars at the top of each lesson jump straight to any lesson, and every lesson check has a **Show answers** button. A yellow "REVIEW MODE" bar shows at the top of every page, and review progress is saved separately from real trainee progress.
**Before trainees use the site**, set `REVIEW_MODE: false` (in `src/head.html`, then `python3 build.py` and `python3 lock.py`), or ask Claude to rebuild it with review mode off. In review mode anyone can reach the exam and certificate without doing the lessons.

## Records library & Admin login
Every trainee who passes is sent to a **Google Sheet** (the records library) through a small Google Apps Script (`records/Code.gs`). The **Admin** button at the top right of the language page opens an admin login. The admin password is checked by the Google script, never in the page. Admins can search the records, see totals and **Download Excel (.xlsx)**, and there's a link to the Google Sheet itself.
- One-time setup: follow `records/SETUP_RECORDS_LIBRARY.md`, then put the web-app URL in `RECORDS_URL` in `CONFIG`, rebuild (`python3 build.py`, `python3 lock.py`) and upload `index.html`.
- Until `RECORDS_URL` is set, the Admin page says the library isn't connected, and nothing is sent.
- Each record includes: completed date/time, certificate ID, name, EL #, position, company, project, supervisor, language, score, number correct, mode (Live or Review) and course version. Records are de-duplicated by certificate ID, and a failed send retries the next time the trainee opens the course on that device.
- Records made while `REVIEW_MODE` is on are marked "Review" and hidden in the admin view by default.
- **Passwords:** once connected, admins can change both the course (entry) password and the admin password from **Admin → Passwords**, with no rebuild. The course is locked with a random key; the Google script stores that key protected by the current course password, and the entry screen fetches it. Until the first change (or if the library isn't connected) the password built into the file is used. See `records/SETUP_RECORDS_LIBRARY.md`.

## SSSP coverage map
Every section of the STY 2A SSSP maps to a module. Pages are the plan's printed page numbers.

| # | Module | SSSP sections & pages |
|---|--------|-----------------------|
| 01 | Policy, Management & Enforceability | Front matter · pp. 1–3 · Appendix D (revision log) |
| 02 | Zero-Tolerance, Mission & Life Saving Rules | pp. 3–6 |
| 03 | Fortis Leadership Roles & Responsibilities | pp. 6–10 |
| 04 | Specialty Roles & Subcontractor Safety Responsibility | pp. 11–14 |
| 05 | Everyone's Responsibility, Safe Work Practices & Access Control | pp. 14–15 |
| 06 | 1.0 Assured Grounding & 2.0 Bulk Fuel Storage | p. 16 |
| 07 | 3.0 Buried Utilities & Appendix A "Don't Hit It" | pp. 16–18 · App. A pp. 49–51 |
| 08 | 4.0 Equipment, 5.0 Discipline, 6.0 Drug & Alcohol, 7.0 Devices | pp. 18–20 |
| 09 | 8.0 Emergency Action & Response | pp. 20–22 |
| 10 | 9.0 Environmental Quality, 10.0 Equipment Qualification, 11.0 Tools | pp. 22–24 |
| 11 | 12.0 Hazard Communication & 13.0 Hazard Correction | pp. 25–27 |
| 12 | 14.0 Heat Illness Prevention & Appendix C | p. 27 · App. C pp. 54–59 |
| 13 | 15.0 High-Risk Mitigation, 16.0 Hot Work/Fire, 17.0 Incentive Program | pp. 28–29 |
| 14 | 18.0 Incident Management | pp. 29–32 |
| 15 | 19.0 JHA & PTP, Appendix B & 20.0 Observations | pp. 32–35 · App. B pp. 52–53 |
| 16 | 21.0 LOTO, 22.0 Notification of Hazards, 23.0 PPE | pp. 35–37 |
| 17 | 24.0 Record Keeping, 25.0 Loss Control, 26.0 Meetings, 27.0 Sanitation | pp. 37–39 |
| 18 | 28.0 Orientation, 29.0 SSSP, 30.0 Steel Erection | pp. 39–41 |
| 19 | 31.0 Stretch & Flex, 32.0 Temporary Power, 33.0 Training | pp. 41–42 |
| 20 | 34.0 Pathways & Vehicle Traffic, 35.0 Weapons | pp. 43–44 |
| 21 | 36.0 Working at Height: Fall Protection & Ladders | pp. 44–46 |
| 22 | 37.0 Spotters, 38.0 High Winds, 39.0 Management of Change | pp. 46–48 |

## How this differs from the STY 10 course
STY 2A's plan is not a copy of STY 10's, so the lessons follow STY 2A wherever they differ. The biggest changes:
- No Fatigue Management section and no Hazardous Energy Control Procedure appendix (§21.0 refers to the HECP as "Appendix 15" but the plan doesn't include it), so those modules are gone.
- No Hurt Matrix pages, no lightning 20/10-mile rules, no WorkRight NorthWest and no ladder permits in this plan.
- Near misses and first aid are reported within 4 hours (STY 10 said 2). A&D testing starts at more than $500 of property damage (STY 10 said $1,000).
- Steel erection hoisting plans are due 14 days before work (STY 10 said 3 working days).
- Subs with fewer than 10 people need a designated safety professional who's readily available off site. Night shift needs at least 1 additional EHS rep.
- Heat plans come from the OR OSHA approved Heat Illness Prevention Plan. The mandatory meetings list Safety Sync Meetings, and the Poker Chip drawing is every other week.
- Module 01 teaches the Rev. 2.0 changes in Appendix D, including drivers and spotters wearing PPE when they get out of the vehicle.

## Where the SSSP contradicts itself
The course points these out and teaches the stricter reading:
- **Don't Hit It lead time:** 48 hrs / 2 days in §3.0, but 3 days in §19.0 → teach **3 days**.
- **CPR/First Aid/AED:** Foreman-level and above in §8.0, but Crew Lead-level and above in §33.0 → teach **Crew Lead and above**.
- The plan also has names left over from other projects ("STY3A", "STY3", "Meta"). The course uses STY 2A.

## Look & media
- **Fortis branding everywhere:** teal, slate, olive and red on every screen, with the Fortis logo in the header next to the course title, on the sign-in screen and on the certificate.
- **Icons:** each module has its own icon (gavel, hard hat, lock, crane, ladder and so on). They come from [Tabler Icons](https://tabler.io/icons) (MIT license) and are built into the page.
- **Photos:** lesson photos from 21 Wikimedia Commons files and the 9 GHS hazard pictograms (Module 11, §12.0 HazCom). They load from **Wikimedia Commons** (freely licensed or public domain), and each caption links to the file page showing its author and license. The sign-in background is the Virginia Range east of Reno.
- Photos need an internet connection. If one can't load, it hides itself and the lesson still works.
- To swap a photo, edit the lesson's `photos` list (`file` is the exact Wikimedia Commons file name, `cap` is the caption). Change it in both the English and Spanish files.

## Settings (`CONFIG` at the top of the script in `index.html`)
```js
COMPANY:      'Fortis Construction, Inc.',
ISSUER_NAME:  'Donavan Griffen',
ISSUER_TITLE: 'Campus Site Lead',
EMAILS:       [],      // e.g. ['safety@yourco.com'] — empty hides the Email button
PASS_PCT:     80,
EXAM_COUNT:   50,
```

## Password
The page asks for a password before anything loads (English/Spanish prompt, with a "Remember on this device" option). The course is **encrypted with the password** (AES-256, key from PBKDF2-SHA256), so someone who opens the page source or downloads the file sees only scrambled data, not the lessons.
- Share the password only with people who should take the training. It is deliberately **not** written in this README, because the repository is public.
- Once the records library is connected, change it from **Admin → Passwords** (no rebuild). Before that, rebuild with `python3 build.py`, then `python3 lock.py "NewPassword"`, and upload the new `dist/index.html` as `index.html`.
- Trainee progress is not affected by the password.

## Publish on GitHub Pages
1. Create a repository and upload `index.html` and `README.md` to the root.
2. Go to **Settings → Pages → Build and deployment → Source: Deploy from a branch**, choose branch `main` and folder `/ (root)`, then Save.
3. After a minute or so the site is live at `https://<your-username>.github.io/<repo-name>/`.

The page only loads two outside resources: Google Fonts and the jsPDF library (cdnjs). If jsPDF can't load, the Download button falls back to Print → Save as PDF.

> **Heads-up:** GitHub Pages sites on free accounts are public. The password keeps the course content encrypted, but the address itself is public and anyone with the password can get in. Confirm with Fortis and the client that this level of protection is okay for the site-security content in the course (badging, photography, access, the control-lock color matrix, trade partner names).

## Spanish version
- Latin American Spanish, using the same site terms as the earlier LOTO Rev 4 Spanish training (for example Vivo-Muerto-Vivo, Persona Calificada, Mariscal de Energía, Dueño del Sistema).
- Fortis form and program names stay in English where crews will see them that way on site (Don't Hit It, Grab & Go, Stretch & Flex, All-Hands, PTP, JHA, SBS, MOP). The Spanish text explains each one.
- The Spanish footer notes that the English SSSP governs if the translation and the SSSP ever differ.
- It's a good idea to have a bilingual reviewer read the Spanish lessons before rollout.

## Editing content
The source files are in `src/` (in the source ZIP) and `index.html` is built from them with `python3 build.py` and `python3 lock.py`:
- `src/en/m01.js … m22.js` hold the English modules and `src/es/m01.js … m22.js` the Spanish, one module per file. `src/head.html` holds the styles and `CONFIG`; `src/tail.html` holds the app code, hero image, GHS pictograms and matching sets.
- Each module has `id`, `icon` (a [Tabler](https://tabler.io/icons) name), `title`, `short`, `ref` (the SSSP sections/pages), `objectives` and `lessons`.
- Each lesson has `sec` (the SSSP badge), `h` (heading), `photos`, `html` and `q`, a list of questions written as `[question, [options], correct index, explanation]`.
- Keep the English and Spanish files in the same shape: same lessons, same question order and the same correct index.
- You can also edit `index.html` directly; the same `COURSE_EN.push(...)` / `COURSE_ES.push(...)` blocks are inside it.
- When the SSSP is revised, update `SOURCE_DOC`, then the affected lessons, `sec` badges and questions.

## Adding more matching activities
Matching sets live in `MATCH_SETS` (English and Spanish pairs). To add one to any lesson, put `<div class="dnd" data-set="yourSetName"></div>` in the lesson HTML and add a set with the same name.
