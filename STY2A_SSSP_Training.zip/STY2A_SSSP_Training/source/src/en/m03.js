{id:'m3', icon:'users', title:'Fortis Leadership Roles & Responsibilities', short:'Safety as a value, Senior Management, PM, Superintendent, PE, Safety Manager, Safety Rep, Safety Administrator',
 ref:'SSSP pp. 6–10',
 objectives:['Explain "Safety as a Value" and the IFE philosophy','List the safety duties of Fortis Senior Management, PMs, Superintendents and PEs','Describe the Fortis Safety Manager\'s coverage, duties, authority and escalation process','List the duties of the Safety Engineer/Rep and the files the Safety Administrator keeps'],
 lessons:[
{sec:'Leadership Roles · p. 6', h:'Safety as a Value',
 html:`<p>At Fortis, safety is <b>more than a statistic</b> at a project level. Fortis approaches safety as a value through a philosophy called <b>"IFE" (Injury Free Environment)</b>.</p>
<ul><li>The goal is a mindset among everyone on the project that promotes safety as a value.</li>
<li>Everyone is committed to going home in the <b>same condition (or better)</b> than how they came to work.</li>
<li>In an IFE, subcontractors not only look out for themselves but <b>watch out for each other's well-being</b>.</li></ul>`,
 q:[['Under the IFE philosophy, subcontractors are expected to:',['Watch out for their own crew members only','Leave watching out for others to Fortis Safety','Report injuries to others, not intervene','Watch out for themselves and each other'],3,'In an IFE, subcontractors not only look out for themselves but watch out for each other\'s well-being.'],
    ['What does "IFE" stand for?',['Injury Free Environment','Incident Free Environment','Injury Free Evaluation','Inspection Frequency Estimate'],0,'Fortis implements a philosophy termed "IFE", which stands for "Injury Free Environment."'],
    ['Under Safety as a Value, everyone is committed to going home:',['Having met the day\'s production goals safely','In the same condition (or better) than they arrived','With zero recordables for the week','No worse than after a normal workday'],1,'Everyone is committed to going home in the same condition (or better) than how they came to work.']]},
{sec:'Senior Management · p. 6', h:'Fortis Senior Management',
 html:`<p>Fortis Senior Management is responsible for:</p>
<ul><li>Encouraging, reinforcing and modeling Fortis culture, including <b>IFE initiatives</b></li>
<li>Participating in the development and assessment of <b>EHS leading indicators</b></li>
<li><b>Reviewing and approving project corrective action plans</b></li>
<li><b>Instituting accountability</b> when action plans and culture are not maintained</li></ul>`,
 q:[['Who reviews and approves project corrective action plans?',['The Fortis Project Manager','The Fortis Safety Manager','The client\'s EHS team','Fortis Senior Management'],3,'Senior Management reviews and approves project corrective action plans.'],
    ['What does Senior Management do when action plans and culture are not maintained?',['Issues a safety stand-down','Hires more safety staff','Institutes accountability','Refers it to the client'],2,'Senior Management institutes accountability when action plans and culture are not maintained.'],
    ['Senior Management takes part in developing and assessing:',['EHS leading indicators','EHS lagging indicators','Subcontract safety budgets','Critical lift plans'],0,'Senior Management participates in the development and assessment of EHS leading indicators.'],
    ['Which part of Fortis culture does Senior Management encourage, reinforce and model?',['Zero-report incentives','IFE initiatives','Lowest-cost bidding','Overtime programs'],1,'Senior Management encourages, reinforces and models Fortis culture, including IFE initiatives.']]},
{sec:'Fortis Project Manager · p. 7', h:'Fortis Project Manager',
 html:`<p>The PM runs construction management services and is responsible for:</p>
<ul><li>Determining whether contract documents and specifications support the project's safety mission</li>
<li>Monitoring subcontractor selection and adherence to guidelines</li>
<li>Holding a <b>start-of-project staff meeting</b> with the team and roving safety rep to assign each safety responsibility using the <b>"Safety Menu of Roles &amp; Responsibilities"</b></li>
<li><b>Periodically auditing subcontractor safety plans</b></li>
<li>Pre-task planning and subcontractor preconstruction safety meetings</li>
<li>Knowing loss-control and public-protection requirements</li>
<li>Fact finding, root cause analysis and corrective actions after incidents</li>
<li><b>Reviewing weekly jobsite safety observations/audits</b></li>
<li><b>Facilitating craft feedback luncheons</b></li>
<li>Supporting corrective actions to comply with the SSSP and the client's <b>Construction, Health and Safety Requirements Document (Exhibit U)</b></li>
<li>Promoting IFE culture</li></ul>`,
 q:[['What tool does the Fortis PM use at the start-of-project staff meeting to assign safety duties?',['The Safety Committee\'s roles and duties chart','The subcontractor Safety Matrix of Duties','The "Safety Menu of Roles & Responsibilities"','The client\'s Exhibit U responsibility checklist'],2,'The PM holds a staff meeting at project start to establish responsibilities using the "Safety Menu of Roles & Responsibilities".'],
    ['What is the client\'s Construction, Health and Safety Requirements Document called in the SSSP?',['Exhibit A','Appendix E','Exhibit S','Exhibit U'],3,'The PM supports compliance with the SSSP and the client\'s Construction, Health and Safety Requirements Document (Exhibit U).'],
    ['How often does the Fortis PM review jobsite safety observations/audits?',['Daily','Weekly','Monthly','Biweekly'],1,'The PM reviews weekly jobsite safety observations/audits.'],
    ['What does the Fortis PM do with subcontractor safety plans?',['Periodically audits them for compliance','Writes them for subs lacking a safety pro','Reviews them once at the precon meeting','Forwards them to the client for approval'],0,'The PM is responsible for periodically auditing subcontractor\'s safety plans for compliance.'],
    ['Which feedback event does the Fortis PM facilitate?',['Client safety walk-throughs','Craft feedback luncheons','Vendor safety fairs','Foreman roundtables'],1,'The PM is responsible for facilitating craft feedback luncheons.']]},
{sec:'Fortis Project Superintendents · p. 7', h:'Fortis Superintendents',
 html:`<p>Superintendents are <b>accountable for all safety responsibilities on jobsites</b>. They:</p>
<ul><li>Oversee planning and execution of all work in compliance with the SSSP</li>
<li>Know the loss-control and public-protection requirements in the contract</li>
<li><b>Complete daily jobsite safety observations/audits</b></li>
<li>Take part in pre-task planning and pre-bid, precon and kickoff meetings</li>
<li>Require supervisors and employees to use <b>PPE</b> per the SSSP, sub programs and regulations</li>
<li>Take part in fact finding and root cause analysis, and help Fortis Safety make sure incident forms and RCAs are complete and forwarded</li>
<li>Encourage Stretch &amp; Flex and weekly toolbox talks, and <b>evaluate their effectiveness</b></li>
<li>Abate unsafe conditions and <b>document corrective actions, forwarding copies to sub safety reps</b></li>
<li>Support Fortis management and project safety personnel in obtaining corrective actions; promote IFE culture</li></ul>`,
 q:[['Which Fortis role is accountable for all safety responsibilities on the jobsite?',['Project Engineer','Safety Administrator','Project Manager','Superintendent'],3,'It is the responsibility of Fortis Superintendents to be accountable for all safety responsibilities on jobsites.'],
    ['How often do Superintendents complete jobsite safety observations/audits?',['Weekly','Daily','Monthly','Quarterly'],1,'Superintendents complete daily jobsite safety observations/audits.'],
    ['After abating an unsafe condition, the Superintendent documents the corrective action and:',['Files the only copy in the Fortis site trailer','Forwards copies to the client\'s EHS team only','Forwards copies to the sub safety representatives','Posts copies at the gate for the next All-Hands'],2,'Superintendents document corrective actions and forward copies to subcontractor safety representatives.'],
    ['Besides encouraging Stretch & Flex and weekly toolbox talks, Superintendents must:',['Evaluate their effectiveness','Shorten them on busy days','Run them only on Mondays','Record attendance only'],0,'Superintendents encourage stretch & flex and weekly toolbox/tailgate safety meetings and evaluate their effectiveness.'],
    ['What must Superintendents require supervisors and employees to use per the SSSP, sub programs and regulations?',['Company-issued radios','Time clocks and gate badge readers','Company vehicles and carts','Personal protective equipment'],3,'Superintendents require supervisors and employees to use PPE in accordance with the SSSP, subcontractor programs and safety regulations.']]},
{sec:'Fortis Project Engineer · pp. 7–8', h:'Fortis Project Engineers',
 html:`<p>The Fortis Project Engineer <b>assists the Fortis Project Manager(s)</b> with construction management. Project Engineers:</p>
<ul><li><b>Complete weekly jobsite safety observations/audits</b></li>
<li>Take part in pre-task planning and subcontractor <b>pre-bid, pre-construction and/or kick-off meetings</b></li>
<li>Assist with jobsite safety startup, safety orientations and <b>craft feedback luncheons</b></li>
<li>Take part in fact finding, RCA and corrective actions <b>to prevent further occurrences</b></li>
<li>Attend and/or participate in jobsite safety meetings</li></ul>`,
 q:[['How often do Project Engineers complete jobsite safety observations/audits?',['Daily','Monthly','Weekly','Quarterly'],2,'Project Engineers complete weekly jobsite safety observations/audits.'],
    ['Who does the Fortis Project Engineer assist?',['The Fortis Superintendent','The Fortis Project Manager(s)','The Fortis Safety Manager','The Safety Administrator'],1,'The Project Engineer assists the Fortis Project Manager(s) with construction management services.'],
    ['Which events does the Project Engineer help with?',['Safety startup, orientations and craft feedback luncheons','Bid openings, client tours and vendor safety fairs','Safety startup, crane lift plans and OSHA inspections','Safety Committee lunches, audits and payroll reviews'],0,'PEs assist with jobsite safety startup, safety orientations and craft feedback luncheons.'],
    ['Why do PEs take part in fact finding, RCA and corrective actions?',['To assign blame to the crew','To close out the insurance claim','To reduce paperwork for Safety','To prevent further occurrences'],3,'PEs participate in fact finding, Root Cause Analysis and implementing corrective actions to prevent further occurrences.']]},
{sec:'Fortis Safety Manager/Professional · p. 8', h:'Fortis Safety Manager: authority and coverage',
 html:`<ul><li>The Fortis Safety Professional has <b>authority for safety and health</b> on all projects.</li>
<li>They are the <b>program administrator</b>, with authority <b>delegated by Fortis Senior Management</b> to implement and promote safety.</li>
<li>A <b>full-time, on-site Fortis Safety Manager</b> is required from <b>mobilization to demobilization</b> whenever there are <b>one or more personnel</b> on the project.</li>
<li><b>Night shift</b> work may require an EHS representative on site.</li>
<li>Specialized high-risk work may require additional EHS coverage and <b>approval by the Client</b>.</li></ul>`,
 q:[['When is a full-time, on-site Fortis Safety Manager required?',['Mobilization to demobilization, when 10 or more are on site','Only during high-risk phases such as steel erection','Day shift only; night shift is covered by the sub','Mobilization to demobilization, whenever anyone is on site'],3,'Starting with mobilization and ending with demobilization, a full-time, onsite Fortis Safety Manager is required for one or more personnel on the project.'],
    ['Specialized high-risk work may require additional EHS coverage and:',['OSHA approval','A second work permit','Client approval','Union approval'],2,'Specialized high-risk work may require additional EHS coverage and approval by the Client.'],
    ['Who delegates authority to the Fortis Safety Professional?',['Fortis Senior Management','The client\'s EHS team','The Fortis Project Manager','The Safety Committee'],0,'The Safety Professional is the program administrator and has the authority delegated by Fortis Senior Management.'],
    ['What may night shift work require?',['A second superintendent','An EHS representative on site','Client approval for each shift','A Lift Director on site'],1,'Night shift work may require an EHS representative to be on-site.']]},
{sec:'Fortis Safety Manager/Professional · p. 8', h:'Safety Professional duties: people, training and hazards',
 html:`<p>Fortis Safety Professional duties include:</p>
<ul><li>Helping familiarize Fortis and sub <b>project managers, superintendents and supervisors</b> with the Fortis SSSP and the <b>Roles &amp; Responsibilities</b></li>
<li>Being familiar with the hazards workers may face and the applicable laws, regulations and safety rules</li>
<li>Supporting project management in achieving an IFE</li>
<li>Helping assure <b>all workers are trained</b> per applicable requirements</li>
<li>Helping assure hazards are <b>observed, inspected, evaluated and abated on a continuing basis</b>, in a timely and effective manner</li>
<li><b>Continually developing new methods</b> for abating hazards</li>
<li><b>Reporting all injuries immediately to Fortis Senior Management</b></li></ul>`,
 q:[['Who does the Fortis Safety Professional report all injuries to, and when?',['Fortis Senior Management, immediately','The client\'s EHS team, within 24 hours','Fortis Senior Management, within 48 hours','The subcontractor\'s PM, by end of shift'],0,'Duties include reporting all injuries immediately to Fortis Senior Management.'],
    ['What does the Safety Professional help familiarize Fortis and sub leaders with?',['The client\'s Exhibit U and the bid documents','The Fortis SSSP and the Roles & Responsibilities','The Fortis SSSP and the subcontract pay terms','The project schedule and the crane lift plans'],1,'The Safety Professional helps familiarize Fortis and subcontractor project managers, superintendents and supervisors with the Fortis SSSP and the Roles & Responsibilities.'],
    ['How often must hazards be observed, inspected, evaluated and abated?',['Once per construction phase','After each incident','On a continuing basis','At monthly audits'],2,'The Safety Professional helps assure observation, inspection, recognition, evaluation and abatement of hazards are conducted on a continuing basis.'],
    ['Besides abating known hazards, the Safety Professional is expected to:',['Leave new abatement methods to the subs','Wait for OSHA to publish new methods','Document hazards for the monthly report','Continually develop new ways to abate hazards'],3,'Duties include continually developing new methods for abating hazards.']]},
{sec:'Fortis Safety Manager/Professional · p. 8', h:'Safety Professional duties: overseeing the safety program',
 html:`<p>Safety Professionals oversee development, implementation and maintenance of the project's safety program by:</p>
<ul><li>Requiring subs to incorporate Fortis EHS requirements into their programs and orientation <b>if theirs are less protective</b></li>
<li><b>Expediting corrective actions</b> to abate any observed or potential exposure</li>
<li>Requiring <b>Fortis supervisors to continuously monitor</b> the EHS plan and sub safety performance</li>
<li>Overseeing <b>emergency response procedures</b> and making sure Fortis and sub personnel are trained to manage on-site emergencies</li>
<li>Setting project <b>missions, milestones and reporting indicators</b> for all personnel</li></ul>`,
 q:[['A subcontractor\'s safety program is less protective than Fortis\'s. The Fortis Safety Professional will:',['Accept it, since each sub\'s own program governs its own crews','Report it to OSHA and allow the sub to keep its current program','Remove the sub from the site until it rewrites its whole program','Require the sub to add Fortis EHS rules to its program and orientation'],3,'Safety Professionals require subcontractors to incorporate Fortis EHS requirements if theirs are less protective.'],
    ['Who does the Safety Professional require to continuously monitor the EHS plan and sub safety performance?',['Fortis supervisors','The client\'s EHS team','Sub safety reps only','The Safety Committee'],0,'The Safety Professional requires Fortis supervisors to continuously monitor the EHS plan and the subcontractor\'s safety performance.'],
    ['Regarding emergencies, the Safety Professional:',['Leaves emergency planning and response to the local fire department','Oversees emergency procedures and helps assure personnel are trained','Posts emergency numbers and trains only Fortis staff, not the sub crews','Oversees the procedures, but leaves emergency training to each sub'],1,'The Safety Professional oversees emergency response procedures and helps assure Fortis and subcontractor personnel are trained to manage onsite emergencies.'],
    ['What does the Safety Professional set for all project personnel to strive to meet?',['Production quotas, milestones and overtime targets','Project budgets, schedules and bid targets','Project missions, milestones and reporting indicators','Zero-report goals and incentive payouts'],2,'The Safety Professional sets project missions and milestones and reporting indicators for all project personnel.']]},
{sec:'Fortis Safety Manager/Professional · pp. 8–9', h:'Safety Professional: daily duties and safety files',
 html:`<ul><li>Help ensure the SSSP's guidelines, rules and procedures are followed; be familiar with <b>local emergency services</b>.</li>
<li>Make sure toolbox/tailgate safety meetings happen <b>before work startup</b>. Additional meetings may be required for specific tasks.</li>
<li>Monitor <b>PPE maintenance and inspection</b>, on-site hazards and the <b>physical condition of site personnel</b>.</li>
<li>Perform <b>daily</b> safety observations of work site activities.</li></ul>
<p><b>Safety files</b> kept by the Safety Professional: training and medical certifications, environmental testing, toolbox notes and rosters, observation reports, <b>investigation reports including near misses</b>, injury summaries, safety permits and security issues.</p>`,
 q:[['Which is part of the safety files the Fortis Safety Professional maintains?',['Payroll and certified wage reports','Subcontract bids and change orders','Investigation reports including near misses','Material invoices and delivery tickets'],2,'Safety files include training and medical certifications, environmental testing, toolbox notes, observation reports, investigations including near misses, injury summaries, permits and security issues.'],
    ['When must toolbox/tailgate safety meetings take place?',['Before work startup','At the lunch break','At the end of the week','After the first break'],0,'Safety Professionals help assure toolbox/tailgate safety meetings are conducted before work startup.'],
    ['How often does the Safety Professional perform safety observations of work site activities?',['Weekly','Daily','Monthly','Quarterly'],1,'Safety Professionals perform daily safety observations of work site activities.'],
    ['Besides PPE and on-site hazards, the Safety Professional monitors:',['Fuel levels and equipment hour meters','Material deliveries and laydown areas','Parking and gate traffic on the campus','The physical condition of site personnel'],3,'Safety Professionals help monitor PPE maintenance and inspection, onsite hazards and the physical condition of site personnel.']]},
{sec:'Fortis Safety Manager/Professional · p. 9', h:'Safety Professional: authority to stop work',
 html:`<ul><li>The Fortis Safety Professional has the <b>authority to stop any operation</b> that poses a potential threat to site personnel.</li>
<li>Reports unsafe acts and conditions to the worker's <b>supervisor and/or safety representative</b> for prompt correction.</li>
<li><b>Stops all life-threatening situations immediately</b> upon knowledge. Fortis requires <b>prompt correction</b> of safety infractions.</li>
<li>Helps monitor the <b>subcontractor selection process</b> and adherence to EHS guidelines.</li></ul>`,
 q:[['Which operations can the Fortis Safety Professional stop?',['Only operations performed by Fortis self-perform crews','Any operation, but only after the client has approved','Any operation posing a potential threat to site personnel','Only work at height, in trenches or near live energy'],2,'The Fortis Safety Professional has the authority to stop any operations that pose a potential threat to site personnel.'],
    ['Who does the Safety Professional report unsafe acts and conditions to?',['The worker\'s supervisor and/or safety representative','The client\'s EHS team and OSHA area office','The worker directly, without the supervisor','The Safety Committee at its monthly meeting'],0,'The Safety Professional reports unsafe acts and conditions to the worker\'s supervisor and/or safety representative for prompt corrective action.'],
    ['When must life-threatening situations be stopped?',['After written notice to the sub','Immediately upon knowledge','At the next safety meeting','Within 24 hours of discovery'],1,'The Safety Professional stops all life-threatening situations immediately upon knowledge.'],
    ['Which process does the Safety Professional help monitor?',['Subcontractor payroll and certified wage reports','Material purchasing and supplier qualifications','Design reviews and constructability meetings','Subcontractor selection and adherence to EHS guidelines'],3,'The Safety Professional helps monitor the subcontractor selection process and adherence to established EHS guidelines.']]},
{sec:'Fortis Safety Manager/Professional · p. 9', h:'When a subcontractor does not correct: written notice',
 html:`<p>If a subcontractor does <b>not make immediate corrections after initial notification</b>, the Fortis Safety Professional will:</p>
<ol><li>Notify the sub's <b>Project Management in writing</b> to make prompt corrective action. The notice must <b>cite specific contract or code violations</b>.</li>
<li>Forward copies of the written notice to <b>Fortis supervision and Fortis Senior Management</b>.</li>
<li>Develop direction to resolve outstanding issues and <b>maintain documentation</b> of corrective actions.</li></ol>`,
 q:[['A sub ignores your first verbal correction. What must your written notice to their Project Management include?',['A proposed fine for each violation','The client\'s approval to proceed','Names and photos of the crew','Specific contract or code violations'],3,'Written notification shall cite specific contract or code violations.'],
    ['Copies of the written notice go to:',['The client\'s EHS team and Fortis supervision','The sub\'s foremen and the Safety Committee','Fortis supervision and Fortis Senior Management','Fortis Senior Management and OSHA'],2,'Copies of the written notice are forwarded to Fortis supervision and Fortis Senior Management.'],
    ['Who receives the written notice itself?',['The subcontractor\'s Project Management','The individual worker involved','The subcontractor\'s crew foreman','The client\'s project manager'],0,'The Safety Professional notifies the subcontractor\'s Project Management in writing.'],
    ['What must the Safety Professional maintain while the issue is resolved?',['A log of fines issued to the sub','Documentation of corrective actions','Copies of the sub\'s certified payroll records','Signed statements from each worker'],1,'The Safety Professional develops direction to resolve outstanding issues and maintains documentation of corrective actions.']]},
{sec:'Fortis Safety Manager/Professional · p. 9', h:'Major events and OSHA inspections',
 html:`<ul><li>After a <b>major event</b> (fatality, multiple injuries or property loss), the Safety Professional requires the sub to <b>preserve the accident scene "as is"</b>, including any equipment involved, for a proper investigation.</li>
<li>If necessary, the Safety Professional <b>orders the area or equipment stabilized</b> to prevent further injuries or loss.</li>
<li>If any contractor has an <b>OSHA inspection</b> (federal or state), the Safety Professional notifies <b>Fortis Senior Management</b>.</li>
<li>If citations, warnings or safety violations are issued, the contractor gives copies to the Fortis Safety Professional <b>within 48 hours</b>.</li></ul>`,
 q:[['A contractor receives OSHA citations. Copies must reach the Fortis Safety Professional within:',['24 hours','5 business days','48 hours','72 hours'],2,'Should citations, warnings or safety violations be issued, the contractor provides copies within 48 hours.'],
    ['After a fatality, the scene must be:',['Cleared and cleaned once photos are taken, to prevent injury','Preserved "as is", but equipment is removed for inspection','Released to the sub after the injured are transported','Preserved "as is", including equipment, stabilized only if needed'],3,'The Safety Professional requires the sub to preserve the scene "as is" and orders stabilization if necessary.'],
    ['Which events count as a "major event" here?',['A fatality, multiple injuries or property loss','Any recordable injury or first-aid case','Any OSHA inspection or citation on site','A near miss involving a crane or lift'],0,'A major event is one resulting in a fatality, multiple injuries or property loss.'],
    ['A contractor has an OSHA inspection. Who does the Fortis Safety Professional notify?',['The client\'s EHS team','Fortis Senior Management','The Fortis Project Manager','The Safety Committee'],1,'The Safety Professional notifies Fortis Senior Management should any contractor be subjected to an OSHA (federal or state) inspection.']]},
{sec:'Fortis Project Safety Engineer/Representative · pp. 9–10', h:'Fortis Safety Engineer/Representative',
 html:`<p>Primary responsibility: assure <b>immediate corrective action</b> of observed unsafe acts and conditions. This person:</p>
<ul><li>Reports unsafe acts/conditions to the worker's supervisor and/or safety rep, and <b>stops life-threatening situations immediately</b></li>
<li>Uses the <b>posted Roles &amp; Responsibilities</b> to confirm each team member meets their assigned safety duties</li>
<li><b>Onboards all new site workers</b> per the site-specific safety orientation</li>
<li>Makes <b>daily</b> observations/audits and facilitates <b>daily safety coordination meetings</b> with sub safety reps</li>
<li>Provides materials for and conducts <b>weekly</b> toolbox/safety meetings; reviews reports for attendance; helps implement training</li>
<li>Provides the information needed to obtain <b>motor vehicle records for all crane operators</b> on site</li>
<li>Reports <b>in writing</b> to the sub the names of individuals (and their supervisors) who <b>continually</b> violate requirements, with copies to Fortis supervision and the sub's PM and Safety Rep; Fortis may require their <b>removal from the site</b></li>
<li>Reports all injuries <b>immediately to Fortis EHS management</b>; joins investigations, incident reports and RCAs; promotes IFE</li></ul>`,
 q:[['What is the Safety Engineer/Representative\'s primary responsibility?',['Maintaining the project safety files, permits and orientation logs','Assuring immediate correction of observed unsafe acts and conditions','Approving subcontractor safety professionals before placement','Writing the subcontractors\' JHAs and site-specific safety plans'],1,'The Safety Engineer/Representative\'s primary responsibility is to assure immediate corrective action of observed unsafe acts and unsafe conditions.'],
    ['Who onboards all new site workers according to the site-specific orientation?',['The Fortis Project Safety Administrator','Each subcontractor\'s crew foreman','The Fortis Project Superintendent','The Fortis Safety Engineer/Representative'],3,'The Fortis Safety Engineer/Representative onboards all new site workers according to the Project Site-Specific Safety Orientation.'],
    ['How often does the Safety Rep make site observations and hold coordination meetings with sub safety reps?',['Daily','Weekly','Monthly','Twice a week'],0,'The Safety Rep makes daily job site safety observations/audits and facilitates daily safety coordination meetings with subcontractor safety representatives.'],
    ['What does the Safety Rep use to confirm each team member is meeting their safety duties?',['The weekly toolbox sign-in sheets','The posted Roles & Responsibilities','The daily badge access report','The client\'s Exhibit U checklist'],1,'The Safety Rep uses the posted Roles & Responsibilities to confirm each project team member is meeting their assigned safety responsibility.'],
    ['A worker keeps violating safety rules. What does the Fortis Safety Rep do?',['Gives a verbal warning and logs it for the monthly safety summary report','Takes the worker\'s badge and terminates them from the project directly','Reports names and supervisors to the sub in writing; removal may follow','Reports the worker to OSHA and the client\'s EHS team'],2,'The Safety Rep reports in writing the names of individuals and their supervisors who continually violate requirements; Fortis supervisors may require the sub to remove them.'],
    ['An injury happens. Who does the Safety Rep report it to, and when?',['The sub\'s PM, by the end of the week','The client\'s EHS team, within 24 hours','Fortis EHS management, by end of shift','Fortis EHS management, immediately'],3,'The Safety Rep reports all injuries immediately to Fortis EHS management.']]},
{sec:'Fortis Project Safety Administrator · p. 10', h:'What the Safety Administrator keeps on file',
 html:`<p>The Fortis Project Safety Administrator keeps on file:</p>
<ul><li><b>Worker safety orientation logs</b></li>
<li>Subcontractor safety observation/audit reports (<b>submitted weekly</b> to Fortis)</li>
<li><b>Crane inspection reports</b>: annual reports required <b>before the equipment arrives on site</b>, then <b>monthly</b> inspection reports</li>
<li><b>Weekly</b> toolbox/tailgate safety meeting reports</li>
<li>Miscellaneous documents: confined space permits, excavation/trenching assessments, logs and inspections, demolition engineering surveys</li>
<li>An <b>updated chemical management plan</b>: chemical inventory lists and <b>SDSs for all products used or stored on site</b></li></ul>`,
 q:[['What crane records must the Safety Administrator have on file?',['Monthly inspection before arrival, then annual reports','Annual inspection within 30 days of arrival, then weekly','Daily operator checklists only, kept by the crane crew','Annual inspection before arrival, then monthly reports'],3,'Crane inspection reports: annual reports required prior to equipment arrival on site, monthly inspection reports thereafter.'],
    ['How often do subcontractors submit safety observation/audit reports to Fortis?',['Daily','Weekly','Monthly','Biweekly'],1,'The subcontractor\'s safety observation/audit reports are submitted weekly to Fortis.'],
    ['The chemical management plan on file must include:',['Inventory lists and SDSs for all products used or stored on site','Inventory lists and SDSs only for products over 5 gallons','SDSs for flammable and toxic products, but no inventory','Supplier invoices and SDSs for products in use that week'],0,'The updated chemical management plan includes chemical inventory lists and SDSs for all products used or stored onsite.'],
    ['Which of these is a "miscellaneous document" the Safety Administrator keeps?',['Bid tabulations','Confined space permits','Daily weather and wind reports','Vehicle registrations'],1,'Miscellaneous documentation includes confined space permits, excavation/trenching assessments/logs and inspections, and demolition engineering surveys.'],
    ['Which orientation record does the Safety Administrator keep?',['Visitor badge sign-out sheets','None; each sub keeps its own','Worker safety orientation logs','Orientation video and quiz only'],2,'The Safety Administrator keeps worker safety orientation logs on file.']]}
 ]}
