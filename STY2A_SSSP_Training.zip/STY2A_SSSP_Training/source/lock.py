"""Encrypt dist/inner.html into dist/index.html behind the password gate (AES-256-GCM, PBKDF2-SHA256)."""
import sys,os,re,json,base64,hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os; W=os.path.dirname(os.path.abspath(__file__))
pw=sys.argv[1] if len(sys.argv)>1 else 'FortisconstructionOri1!'
html=open(W+'/dist/inner.html').read().encode()
b=lambda x:base64.b64encode(x).decode()
K=os.urandom(32); iv=os.urandom(12); ct=AESGCM(K).encrypt(iv,html,None)
salt=os.urandom(16); n=250000; kek=hashlib.pbkdf2_hmac('sha256',pw.encode(),salt,n,32); wiv=os.urandom(12)
w=AESGCM(kek).encrypt(wiv,K,None)
g=open(W+'/src/gate_template.html').read()
g=re.sub(r'const D=\{i:"[^"]+",c:"[^"]+"\}',lambda m:f'const D={{i:"{b(iv)}",c:"{b(ct)}"}}',g,count=1)
g=re.sub(r'DEF=\{[^}]*\}',lambda m:'DEF='+json.dumps({"s":b(salt),"i":b(wiv),"n":n,"w":b(w)}),g,count=1)
for a,c in [('STY10 SSSP Safety Professional Training','STY2A SSSP Safety Professional Training'),('Project Comstock · STY 10','Project Comstock · STY 2A'),('sty10_','sty2a_')]:
    assert a in g,(a,); g=g.replace(a,c)
assert 'STY10' not in g and 'STY 10' not in g and 'sty10' not in g
open(W+'/dist/index.html','w').write(g)
print('locked',len(g))
