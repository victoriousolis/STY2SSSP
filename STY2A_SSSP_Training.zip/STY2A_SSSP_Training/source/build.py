"""Build dist/inner.html (the course) from src/head.html + modules + src/tail.html."""
import os
import os; W=os.path.dirname(os.path.abspath(__file__)); S=W+'/src'
N=22
NAME='STY2A SSSP Safety Professional Training'
def rep(s,pairs,label):
    for a,b,*n in pairs:
        c=s.count(a); want=n[0] if n else 1
        assert (c==want) if want else c>=1,(label,c,a[:100])
        s=s.replace(a,b)
    return s
head=open(S+'/head.html').read(); tail=open(S+'/tail.html').read()
head=rep(head,[
 ('<title>STY10 SSSP Safety Professional Training</title>',f'<title>{NAME}</title>'),
 ('Project Comstock STY 10, for incoming','Project Comstock STY 2A, for incoming'),
 ('<span class="bl">STY10 SSSP Safety Professional Training</span><span class="bs">STY10 SSSP Training</span>',f'<span class="bl">{NAME}</span><span class="bs">STY2A SSSP Training</span>'),
 ("Project Comstock STY 10, v1.0 (06-04-2025), including the Hazardous Energy Control Procedure (Rev 03).","Project Comstock STY 2A, Rev. 2.0 (05.2025)."),
 ("PROJECT:       'Project Comstock · STY 10',","PROJECT:       'Project Comstock · STY 2A',"),
 ("SOURCE_DOC:    'Fortis Construction STY 10 SSSP v1.0 (06-04-2025)',","SOURCE_DOC:    'Fortis Construction STY 2A SSSP Rev. 2.0 (05.2025)',"),
 ("STORAGE_KEY:   'sty10_sssp_safetypro_v4',","STORAGE_KEY:   'sty2a_sssp_safetypro_v1',"),
 ("COURSE_VERSION:'SSSP v1.0 · course 2026-09',","COURSE_VERSION:'SSSP Rev 2.0 · course 2026-09',"),
],'head')
tail=rep(tail,[
 ("brand:'STY10 SSSP Safety Professional Training', brandShort:'STY10 SSSP Training'",f"brand:'{NAME}', brandShort:'STY2A SSSP Training'"),
 ("Project Comstock STY 10, v1.0 (06-04-2025), including the Hazardous Energy Control Procedure (Rev 03).","Project Comstock STY 2A, Rev. 2.0 (05.2025)."),
 ("coming onto STY 10. There are ${n} modules that follow the SSSP in order, page by page, from the policy statement through Section 40.0 and the Appendix D Hazardous Energy Control Procedure.","coming onto STY 2A. There are ${n} modules that follow the SSSP in order, page by page, from the policy statement through Section 39.0 and Appendices A–D."),
 ("certBody:d=>`has completed in-depth training on the ${d} and its Hazardous Energy Control Procedure, and passed the final exam.`","certBody:d=>`has completed in-depth training on the ${d} and passed the final exam.`"),
 ("pdfBody:d=>[`has completed in-depth training on the ${d}`,'and its Hazardous Energy Control Procedure, and passed the final exam.']","pdfBody:d=>[`has completed in-depth training on the ${d}`,'and passed the final exam.']"),
 ("mailSubject:'Fortis STY10 SSSP Safety Professional Training: Completion'",f"mailSubject:'Fortis {NAME}: Completion'"),
 ("brand:'SSSP STY10 · Profesionales de Seguridad', brandShort:'SSSP STY10'","brand:'SSSP STY2A · Profesionales de Seguridad', brandShort:'SSSP STY2A'"),
 ("Project Comstock STY 10, v1.0 (06-04-2025), incluido el Procedimiento de Control de Energía Peligrosa (Rev 03).","Project Comstock STY 2A, Rev. 2.0 (05.2025)."),
 ("que llegan a STY 10. Son ${n} módulos que siguen el SSSP en orden, página por página, desde la declaración de política hasta la Sección 40.0 y el Procedimiento de Control de Energía Peligrosa del Apéndice D.","que llegan a STY 2A. Son ${n} módulos que siguen el SSSP en orden, página por página, desde la declaración de política hasta la Sección 39.0 y los Apéndices A–D."),
 ("mailSubject:'Fortis STY 10 SSSP: capacitación para Profesionales de Seguridad completada'","mailSubject:'Fortis STY 2A SSSP: capacitación para Profesionales de Seguridad completada'"),
 ('<h1>STY10 SSSP Safety Professional Training<br><span style="opacity:.85;font-size:.7em">Capacitación SSSP STY10 para Profesionales de Seguridad</span></h1>',f'<h1>{NAME}<br><span style="opacity:.85;font-size:.7em">Capacitación SSSP STY2A para Profesionales de Seguridad</span></h1>'),
 ('value="Project Comstock – STY 10"','value="Project Comstock – STY 2A"'),
 ('FORTIS-STY10-SSSP-','FORTIS-STY2A-SSSP-'),
 ('Fortis_STY10_SSSP_','Fortis_STY2A_SSSP_',0),
 ("'FORTIS CONSTRUCTION, INC. · STY 10 SSSP'","'FORTIS CONSTRUCTION, INC. · STY 2A SSSP'"),
 ("sty10_","sty2a_",0),
 ("'Fortis Construction, Inc. — STY10 SSSP Safety Professional Training'",f"'Fortis Construction, Inc. — {NAME}'"),
],'tail')
import re
def mods(lang):
    out=[]
    for i in range(1,N+1):
        out.append(open(f'{S}/{lang}/m{i:02d}.js').read().rstrip())
    return out
body='const COURSE_EN=[], COURSE_ES=[];\n/* ENGLISH — q: [question, [options], correctIndex, why] */\nCOURSE_EN.push(\n'
body+=',\n'.join(f'/* ================================================================ M{i+1} */\n'+m for i,m in enumerate(mods('en')))
body+='\n);\n\n/* ESPAÑOL — q: [pregunta, [opciones], correctIndex, explicación] */\nCOURSE_ES.push(\n'
body+=',\n'.join(f'/* ================================================================ M{i+1} */\n'+m for i,m in enumerate(mods('es')))
body+='\n);\n\n\n\n\n'
html=head+body+tail
for bad in ['STY 10','STY10','sty10']:
    assert bad not in re.sub(r'data:[^"\']+','',html).replace("'The STY 10 SSSP'","").replace("'El SSSP de STY 10'",""),(bad,)
os.makedirs(W+'/dist',exist_ok=True)
open(W+'/dist/inner.html','w').write(html)
print('built',len(html))
