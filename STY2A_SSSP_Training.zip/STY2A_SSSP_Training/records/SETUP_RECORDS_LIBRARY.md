# Records library setup (Google Sheet) — about 10 minutes, one time

Every trainee who passes the final exam is added as a row in a Google Sheet. Admins log in from the **Admin** button at the top of the course's language page to search the records and download them as an Excel file.

## 1. Create the Sheet
1. Sign in to the Google account that should own the records (ideally a shared Fortis safety account, not a personal one).
2. Go to **sheets.new**. Name the spreadsheet `STY 2A SSSP Training Records`.

## 2. Add the script
1. In the Sheet, click **Extensions → Apps Script**.
2. Delete everything in the editor and paste the whole contents of `Code.gs` (the same `Code.gs` from the STY 10 course works as is).
3. On the line `const ADMIN_PASSWORD = 'CHANGE-ME-before-deploying';`, replace the text between the quotes with the admin password you want. Use something different from the course password. Leave `SUBMIT_TOKEN` as it is.
4. Click **Save** (the disk icon).

## 3. Run setup once
1. In the function menu at the top, choose **setup**, then click **Run**.
2. Google asks for permission: **Review permissions → choose your account → Advanced → Go to (project) → Allow**. This lets the script write to this one spreadsheet.
3. Back in the Sheet, a tab named **Completions** now has a teal header row.

## 4. Publish it as a web app
1. Click **Deploy → New deployment**.
2. Click the gear next to "Select type" and choose **Web app**.
3. Set **Execute as: Me** and **Who has access: Anyone**. ("Anyone" is required so trainees' phones can send their record. Reading records still requires the admin password.)
4. Click **Deploy** and copy the **Web app URL** (it ends in `/exec`).

## 5. Connect the course
Send the Web app URL to whoever builds the course (or Claude). It goes into `RECORDS_URL` in the course settings, the site is rebuilt, and you upload the new `index.html` to GitHub.

## Using it
- **Admin login:** open the course → **Admin** (top right of the language page) → enter the admin password.
- **What you see:** totals, a searchable table, **Download Excel (.xlsx)**, and a link to open the Google Sheet.
- **Review-mode tests** (completions done while the site is in review mode) are marked "Review" and hidden by default. Untick "Hide review-mode tests" to see them.
- The Google Sheet itself is the permanent records library. Share it with other admins from the Sheet's Share button, and don't edit or reorder the header row.

## Changing things later
- **New admin password:** edit `ADMIN_PASSWORD` in Apps Script, Save, then **Deploy → Manage deployments → edit (pencil) → Version: New version → Deploy**. The URL stays the same, so the course doesn't need rebuilding.
- If a trainee's record couldn't be sent (no signal, for example), the course retries automatically the next time they open it on the same device.
